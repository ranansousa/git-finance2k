# IDHttpProgress
Extend por indy IDHttp plus capacity to show progress.

Esta classe extente as fuções do IDHttp para permitir o
monitoramento do andamento do download ou em outras
palavras, um progresso do download.

A unit já está totalmente compatível com Delphi e Lazarus.
